<?php

use Symfony\Component\HttpFoundation\Response;
use function Pest\Laravel\postJson;


it('should run a completion when all fields are valid', function () {
    // Act
    $response = postJson(
        route('chatgpt.prompts.store'),
        [
            'model' => 'gpt-3.5-turbo',
            'temperature' => 0.7,
            'prompt' => [
                [ 'role' => 'user', 'content' => 'What is machine learning?'],
            ],
            'tokens' => 256
        ]
    );

    // Assert
    $response->assertStatus(Response::HTTP_OK)
        ->json('data.result');
});

it('should return 422 when temperature < 0', function () {
    // Act
    $response = postJson(
        route('chatgpt.prompts.store'),
        [
            'model' => 'gpt-3.5-turbo',
            'temperature' => -0.5,
            'prompt' => [
                [ 'role' => 'user', 'content' => 'What is machine learning?'],
            ],
            'tokens' => 256
        ]
    );

    // Assert
    $response->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY);
});

it('should run a completion when temperature = 0', function () {
    // Act
    $response = postJson(
        route('chatgpt.prompts.store'),
        [
            'model' => 'gpt-3.5-turbo',
            'temperature' => 0,
            'prompt' => [
                [ 'role' => 'user', 'content' => 'What is machine learning?'],
            ],
            'tokens' => 256
        ]
    );

    // Assert
    $response->assertStatus(Response::HTTP_OK)
        ->json('data.result');
});

it('should run a completion when temperature = 1', function () {
    // Act
    $response = postJson(
        route('chatgpt.prompts.store'),
        [
            'model' => 'gpt-3.5-turbo',
            'temperature' => 1,
            'prompt' => [
                [ 'role' => 'user', 'content' => 'What is machine learning?'],
            ],
            'tokens' => 256
        ]
    );

    // Assert
    $response->assertStatus(Response::HTTP_OK)
        ->json('data.result');
});

it('should return 422 when temperature > 1', function () {
    // Act
    $response = postJson(
        route('chatgpt.prompts.store'),
        [
            'model' => 'gpt-3.5-turbo',
            'temperature' => 1.5,
            'prompt' => [
                [ 'role' => 'user', 'content' => 'What is machine learning?'],
            ],
            'tokens' => 256
        ]
    );

    // Assert
    $response->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY);
});

it('should return 422 when maximum length < 20', function () {
    // Act
    $response = postJson(
        route('chatgpt.prompts.store'),
        [
            'model' => 'gpt-3.5-turbo',
            'temperature' => 0.5,
            'prompt' => [
                [ 'role' => 'user', 'content' => 'What is machine learning?'],
            ],
            'tokens' => 10
        ]
    );

    // Assert
    $response->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY);
});

it('should run a completion with maximum length = 20', function () {
    // Act
    $response = postJson(
        route('chatgpt.prompts.store'),
        [
            'model' => 'gpt-3.5-turbo',
            'temperature' => 0.7,
            'prompt' => [
                [ 'role' => 'user', 'content' => 'What is machine learning?'],
            ],
            'tokens' => 20
        ]
    );

    // Assert
    $response->assertStatus(Response::HTTP_OK)
        ->json('data.result');
});

it('should run a completion with maximum length = 2500', function () {
    // Act
    $response = postJson(
        route('chatgpt.prompts.store'),
        [
            'model' => 'gpt-3.5-turbo',
            'temperature' => 0.7,
            'prompt' => [
                [ 'role' => 'user', 'content' => 'What is machine learning?'],
            ],
            'tokens' => 2500
        ]
    );

    // Assert
    $response->assertStatus(Response::HTTP_OK)
        ->json('data.result');
});

it('should return 422 when maximum length > 2500', function () {
    // Act
    $response = postJson(
        route('chatgpt.prompts.store'),
        [
            'model' => 'gpt-3.5-turbo',
            'temperature' => 0.5,
            'prompt' => [
                [ 'role' => 'user', 'content' => 'What is machine learning?'],
            ],
            'tokens' => 3000
        ]
    );

    // Assert
    $response->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY);
});

it('should return 422 when prompt is not an array', function () {
    // Act
    $response = postJson(
        route('chatgpt.prompts.store'),
        [
            'model' => 'gpt-3.5-turbo',
            'temperature' => 0.5,
            'prompt' => 'What is machine learning?',
            'tokens' => 3000
        ]
    );

    // Assert
    $response->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY);
});

it('should return 422 when prompt array is missing the "role" field', function () {
    // Act
    $response = postJson(
        route('chatgpt.prompts.store'),
        [
            'model' => 'gpt-3.5-turbo',
            'temperature' => 0.5,
            'prompt' => [
                [ 'content' => 'What is machine learning?'],
            ],
            'tokens' => 3000
        ]
    );

    // Assert
    $response->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY);
});

it('should return 422 when prompt array is missing the "content" field', function () {
    // Act
    $response = postJson(
        route('chatgpt.prompts.store'),
        [
            'model' => 'gpt-3.5-turbo',
            'temperature' => 0.5,
            'prompt' => [
                [ 'role' => 'user'],
            ],
            'tokens' => 3000
        ]
    );

    // Assert
    $response->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY);
});
