<?php

use Inertia\Testing\AssertableInertia as Assert;

it('should load OpenAI API Index page', function () {
    // Act
    $response = $this->get(route('openai.show'));

    $this->followRedirects($response);

    // Assert
    $response->assertOk();
});

it('should load the correct InertiaJS Page', function () {
    // Act
    $response = $this->get(route('openai.show'));

    // Assert
    $response->assertInertia(fn (Assert $page) => $page->component('OpenAI/Index'));
});

it('should load the models data property together in the response', function () {
    // Act
    $response = $this->get(route('openai.show'));

    // Assert
    $response->assertInertia(fn (Assert $page) => $page->has('models'));
});
