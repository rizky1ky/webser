<?php

namespace App\OpenAI\Actions;

use App\OpenAI\Http\Requests\CompletionRequest;
use OpenAI\Laravel\Facades\OpenAI;
use OpenAI\Responses\Completions\CreateResponse;

class CreateCompletion
{
    public static function execute(CompletionRequest $request): CreateResponse
    {
        return OpenAI::completions()->create([
            'model' => $request->model,
            'prompt' => $request->prompt,
            'temperature' => floatval($request->temperature),
            'max_tokens' => intval($request->tokens),
        ]);
    }
}
