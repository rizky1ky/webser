<?php

namespace App\OpenAI\Actions;

use App\OpenAI\Http\Requests\ChatRequest;
use OpenAI\Laravel\Facades\OpenAI;
use OpenAI\Responses\Chat\CreateResponse;
class CreateChat
{
    public static function execute(ChatRequest $request): CreateResponse
    {
          return OpenAI::chat()->create([
            'model' => $request->model,
            'temperature' => floatval($request->temperature),
            'max_tokens' => intval($request->tokens),
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'You are ChatGPT, a large language model trained by OpenAI. Answer as concisely as possible.',
                ],
                ...$request->prompt,
            ],
          ]);
    }
}