<?php

namespace App\OpenAI\Actions;

use OpenAI\Laravel\Facades\OpenAI;

class LoadCompletionModels
{
    public static function execute(): array
    {
        return [
            'text-davinci-003',
            'text-curie-001',
            'text-babbage-001',
            'text-ada-001',
            'code-davinci-002',
            'code-cushman-001',
        ];
    }
}
