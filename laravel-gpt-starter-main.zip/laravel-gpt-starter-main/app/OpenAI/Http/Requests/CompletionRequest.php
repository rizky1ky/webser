<?php

namespace App\OpenAI\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CompletionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'model' => ['required', 'string'],
            'prompt' => ['required', 'string'],
            'temperature' => ['required', 'numeric', 'min:0', 'max:1'],
            'tokens' => ['required', 'integer', 'min:20', 'max:2500'],
        ];
    }
}
