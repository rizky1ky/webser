<?php

namespace App\OpenAI\Http\Requests;

use Illuminate\Contracts\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class ChatRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, Rule|array|string>
     */
    public function rules(): array
    {
        return [
            'model' => ['required', 'string'],
            'prompt' => ['required', 'array'],
            'prompt.*.role' => ['required', 'string'],
            'prompt.*.content' => ['required', 'string'],
            'temperature' => ['required', 'numeric', 'min:0', 'max:1'],
            'tokens' => ['required', 'integer', 'min:20', 'max:2500'],
        ];
    }
}
