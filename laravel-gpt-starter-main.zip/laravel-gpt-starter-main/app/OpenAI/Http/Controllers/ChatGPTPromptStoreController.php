<?php

namespace App\OpenAI\Http\Controllers;

use App\Http\Controllers\Controller;
use App\OpenAI\Actions\CreateChat;
use App\OpenAI\Http\Requests\ChatRequest;
use App\OpenAI\Http\Resources\ChatResource;

class ChatGPTPromptStoreController extends Controller
{

    /**
     * @param ChatRequest $request
     * @return ChatResource
     */
    public function __invoke(ChatRequest $request): ChatResource
    {
        $result = CreateChat::execute($request);
        return ChatResource::make($result);
    }
}
