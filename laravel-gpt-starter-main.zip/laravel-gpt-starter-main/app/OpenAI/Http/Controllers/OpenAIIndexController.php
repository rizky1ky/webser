<?php

namespace App\OpenAI\Http\Controllers;

use Illuminate\Http\Request;
use App\OpenAI\Actions\LoadCompletionModels;
use App\Http\Controllers\Controller;
use App\OpenAI\Http\Resources\ModelResource;

class OpenAIIndexController extends Controller
{
    /**
     * Handle the incoming request.
     */
    public function __invoke(Request $request)
    {
        // load models
        $models = LoadCompletionModels::execute();

        return inertia()->render('OpenAI/Index', [
            'models' => $models,
        ]);
    }
}
