<?php

namespace App\OpenAI\Http\Controllers;

use Illuminate\Http\Request;
use App\OpenAI\Actions\LoadChatModels;
use App\Http\Controllers\Controller;
use App\OpenAI\Http\Resources\ModelResource;

class ChatGPTIndexController extends Controller
{
    /**
     * Handle the incoming request.
     */
    public function __invoke(Request $request)
    {
      // load models
      $models = LoadChatModels::execute();

      return inertia()->render('ChatGPT/Index', [
          'models' => $models,
      ]);
    }
}
