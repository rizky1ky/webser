<?php

namespace App\OpenAI\Http\Controllers;

use App\Http\Controllers\Controller;
use App\OpenAI\Actions\CreateCompletion;
use App\OpenAI\Http\Requests\CompletionRequest;
use App\OpenAI\Http\Resources\CompletionResource;

class OpenAIPromptStoreController extends Controller
{
    /**
     * @param CompletionRequest $request
     * @return CompletionResource
     */
    public function __invoke(CompletionRequest $request): CompletionResource
    {
        $result = CreateCompletion::execute($request);

        return CompletionResource::make($result);
    }
}
