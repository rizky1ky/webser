<script setup>
import { onMounted, ref } from 'vue';

const props = defineProps(['modelValue']);
const emit = defineEmits(['update:modelValue']);
const message = ref();
const prompt = ref();

const onPrompt = () => {
    emit('update:modelValue', message.value);
    message.value = '';
    focusPrompt();
};

onMounted(() => focusPrompt());

const focusPrompt = () => {
    prompt.value.focus();
};
</script>

<template>
    <div class="lg:max-w-4xl w-full flex">
        <div
            class="w-full border-black/10 bg-white px-2 py-4 rounded-md shadow-[0_0_10px_rgba(0,0,0,0.10)]">
            <input @change="onPrompt" autofocus placeholder="Chat with me"
                ref="prompt" v-model="message"
                class="p-0 m-0 placeholder-slate-400 resize-none text-slate-600 text-base border-0 outline-none focus:outline-none focus:ring-0 focus:ring-offset-0 w-full" />
        </div>
    </div>
</template>
