<template>
    <Listbox as="div" v-model="selected">
        <div class=" relative mt-1">
            <ListboxButton
                class="relative w-full cursor-pointer rounded-md border border-zinc-300 bg-transparent py-2 pl-3 pr-10 text-left shadow-sm focus:outline-none focus:ring-1">
                <span class="truncate h-6 flex flex-col justify-center">{{
                    selected
                }}</span>
                <span class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2">
                    <ChevronUpDownIcon class="h-5 w-5 text-white" aria-hidden="true" />
                </span>
            </ListboxButton>

            <transition leave-active-class="transition ease-in duration-100" leave-from-class="opacity-100"
                leave-to-class="opacity-0">
                <ListboxOptions
                    class="absolute z-10 mt-1 max-h-60 w-full overflow-auto rounded-md bg-zinc-700 py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm">
                    <ListboxOption as="template" v-for="option in options" :key="option" :value="option"
                        v-slot="{ active, selected }">
                        <li
                            :class="[active ? 'bg-indigo-600' : 'bg-transparent', 'relative cursor-default select-none py-2 pl-8 pr-4 text-white']">
                            <span :class="[selected ? 'font-semibold' : 'font-normal', 'block truncate']">{{
                                option
                            }}</span>

                            <span v-if="selected" class="absolute inset-y-0 left-0 flex items-center pl-1.5 text-white">
                                <CheckIcon class=" h-5 w-5" aria-hidden="true" />
                            </span>
                        </li>
                    </ListboxOption>
                </ListboxOptions>
            </transition>
        </div>
    </Listbox>
</template>

<script setup>
import { Listbox, ListboxButton, ListboxOption, ListboxOptions } from '@headlessui/vue'
import { CheckIcon, ChevronUpDownIcon } from '@heroicons/vue/20/solid'
import { onMounted, ref, watch } from 'vue';

const props = defineProps(['modelValue', 'options']);
const emit = defineEmits(['update:modelValue']);

let initialized = false;
const selected = ref();

onMounted(() => {
    if (!initialized) {
        selected.value = props.modelValue;
        initialized = true;
    }
});

watch(() => props.modelValue, () => {
    selected.value = props.modelValue;
});

watch(selected, () => emit('update:modelValue', selected.value));
</script>



