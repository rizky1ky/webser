<template>
    <div>
        <input type="range" :value="modelValue"
            @input="$emit('update:modelValue', $event.target.value)" :min="min"
            :max="max" :step="step" class="w-full h-2 rounded-lg bg-zinc-700 accent-zinc-700 cursor-grabbing
        ">
    </div>
</template>

<script setup>
defineProps(['modelValue', 'min', 'max', 'step']);
defineEmits(['update:modelValue']);
</script>
