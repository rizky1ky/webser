<template>
    <button type="button" title="New Dialog"
        class="w-full inline-flex rounded-md border border-zinc-100 px-4 py-2 text-md font-medium text-white shadow-sm bg-secondary hover:bg-primary focus:outline-none transition duration-200 ease-in-out">
        <span class="md:mr-3">+</span> <span class="hidden md:inline-block">New Dialog</span>
    </button>
</template>

<script setup>
</script>
