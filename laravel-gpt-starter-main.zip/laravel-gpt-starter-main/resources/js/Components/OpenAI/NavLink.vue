<script setup>
import { computed } from 'vue';
import { Link } from '@inertiajs/vue3';

const props = defineProps(['href', 'active']);

const classes = computed(() =>
    props.active
        ? 'inline-flex items-center border-b-2 px-1 py-1 pb-2 text-sm font-medium border-zinc-800 text-gray-900'
        : 'inline-flex items-center border-b-2 px-1 py-1 pb-2 text-sm font-medium border-transparent text-zinc-500 hover:border-zinc-300 hover:text-zinc-700'
);
</script>

<template>
    <Link :href="href" :class="classes">
    <slot />
    </Link>
</template>
