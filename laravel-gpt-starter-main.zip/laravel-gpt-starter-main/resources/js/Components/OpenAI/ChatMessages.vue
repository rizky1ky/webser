<script setup>
import { nextTick, ref, watch } from 'vue';
import SystemAvatar from '@/Components/OpenAI/SystemAvatar.vue';
import MyAvatar from '@/Components/OpenAI/MyAvatar.vue';

const props = defineProps(['messages']);
const scrollHere = ref("");

watch(() => props.messages, () => {
    nextTick(() => {
        scrollHere.value?.scrollIntoView();
    });
}, { deep: true });

const getAvatar = ({ owner }) => {
    return owner === 'me' ? MyAvatar : SystemAvatar;
}
</script>

<template>
    <div ref="chat" class="scroll-smooth">
        <div class="flex justify-center text-left mx-auto" :class="[index % 2 === 0 ? 'bg-zinc-50' : 'bg-white']"
            v-for="(message, index) in messages" :key="message.content">
            <div class=" w-full lg:max-w-7xl lg:w-8/12 flex p-4">
                <dt class="text-center px-2 mr-5">
                    <component :is="getAvatar(message)" />
                </dt>
                <dd class="text-md text-zinc-900 px-2">
                    <div>{{ message.content }}</div>
                </dd>
            </div>
        </div>
        <div ref="scrollHere" />
    </div>
</template>
