<template>
    <div class="flex flex-col">
        <div class="flex justify-between items-baseline">
            <h3 class="text-lg font-medium leading-6 py-2 text-white">
                {{ title }}</h3>
            <span>
                <slot name="info" />
            </span>
        </div>
        <slot name="default" />
        <p class="mt-1 text-sm text-zinc-500">
            <slot name="description" />
        </p>
    </div>
</template>

<script setup>
defineProps(['title', 'description']);
</script>
