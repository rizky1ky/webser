<script setup>
import { ref, useSlots, watch } from 'vue';
import NavLink from '@/Components/OpenAI/NavLink.vue';

const slots = useSlots();
const isOpen = ref(false);
const openMenu = () => isOpen.value = !isOpen.value;

watch(isOpen, () => {
    if (isOpen) {
        document.body.style.setProperty("overflow", "hidden");
    } else {
        document.body.style.removeProperty("overflow");
    }
});
</script>

<template>
    <div class="w-screen h-screen bg-white">
        <div class="flex h-full flex-col">
            <div class="flex justify-center border-b-2">
                <nav
                    class="flex w-full justify-between px-6 h-16 bg-white text-zinc-700 border-b border-gray-200 items-stretch">
                    <div class="flex items-center justify-center space-x-4">
                        <button aria-label="Open Menu" @click="openMenu" v-if="slots.menu">
                            <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                stroke-width="2" viewBox="0 0 24 24" class="w-8 h-8">
                                <path d="M4 6h16M4 12h16M4 18h16"></path>
                            </svg>
                        </button>
                        <div>
                            <slot name="menu-bar" />
                        </div>
                    </div>
                    <div class="flex space-x-8">
                        <NavLink :href="route('openai.show')" :active="route().current('openai.show')">
                            OpenAI API
                        </NavLink>
                        <NavLink :href="route('chatgpt.show')" :active="route().current('chatgpt.show')">
                            ChatGPT API
                        </NavLink>
                    </div>

                    <transition enter-class="opacity-0" enter-active-class="ease-out transition-medium"
                        enter-to-class="opacity-100" leave-class="opacity-100"
                        leave-active-class="ease-out transition-medium" leave-to-class="opacity-0">
                        <div @keydown.esc="isOpen = false" v-show="isOpen" class="z-10 fixed inset-0 transition-opacity">
                            <div @click="isOpen = false" class="absolute inset-0 bg-black opacity-50" tabindex="0">
                            </div>
                        </div>
                    </transition>

                    <aside
                        class="top-0 left-0 w-[320px] text-white fixed h-full overflow-auto ease-in-out transition-all duration-300 z-30"
                        :class="isOpen ? 'translate-x-0' : '-translate-x-full'">
                        <slot name="menu" />
                    </aside>
                </nav>
            </div>
            <div class="h-full flex-1 overflow-hidden">
                <slot />
            </div>
        </div>
    </div>
</template>
