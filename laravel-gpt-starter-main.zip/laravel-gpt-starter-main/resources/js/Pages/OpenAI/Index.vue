<script setup>
import { ref, watch } from 'vue';
import { Head, useForm } from '@inertiajs/vue3';
import debounce from 'lodash/debounce';
import axios from 'axios';
import OpenAILayout from '@/Layouts/OpenAILayout.vue';
import NewDialogButton from '@/Components/OpenAI/NewDialogButton.vue';
import ChatMessages from '@/Components/OpenAI/ChatMessages.vue';
import Prompt from '@/Components/OpenAI/Prompt.vue';
import Section from '@/Components/OpenAI/Section.vue';
import Select from '@/Components/OpenAI/Select.vue';
import Slider from '@/Components/OpenAI/Slider.vue';

const props = defineProps(['models']);

const refreshKey = ref(0);

const description = {
    'models': "The OpenAI API is powered by a set of models with different capabilities and price points. Our base GPT-3 models are called Davinci, Curie, Babbage and Ada",
    'temperature': " The temperature controls how much randomness is in the output. In general, the lower the temperature, the more likely GPT-3 will choose words with a higher probability of occurrence.",
    'tokens': "The text prompt and generated completion combined must be no more than the model's maximum context length(for most models this is 2048 tokens, or about 1500 words). 1 token is approximately 4 characters or 0.75 words for English text.",
};

const messages = ref([]);

const form = useForm({
    temperature: 0.7,
    model: 'text-davinci-003',
    prompt: '',
    tokens: 256,
});

const onNewChat = () => {
    refreshKey.value += 1; // refresh prompt section
    messages.value.splice(0, messages.value.length);
};

watch(() => form.prompt, () => {
    onPrompt();
});

const prepareData = () => {
    let prompt = '';

    if (messages?.value?.length === 1) {
        prompt = form.prompt;
    }

    if (messages?.value?.length > 2) {
        prompt = messages.value.slice(-3).map((message) => message?.content).join('\n\n');
    }

    return {
        ...form.data(),
        prompt
    }
};

const addMessage = ({ owner = '', content }) => {
    messages.value.push({
        owner,
        content,
    });
};

const onPrompt = debounce(() => {
    if (!form.prompt) {
        return;
    }

    addMessage({
        owner: 'me',
        content: form.prompt
    });

    axios.post(route('openai.prompts.store'), prepareData())
        .then(response => response?.data?.data)
        .then(response => {
            addMessage({
                content: response?.result,
            });
            form.reset('prompt');
        });
}, 500);
</script>

<template>
    <Head title="OpenAI API" />

    <OpenAILayout>
        <template #menu>
            <div class="h-full bg-zinc-800 p-2.5 px-4">
                <div class="min-full-h w-full">
                    <div class="mt-2">
                        <Section title="Models">
                            <Select v-model="form.model" :options="models" />
                            <template #description>
                                {{ description.models }}
                            </template>
                        </Section>
                    </div>
                    <div class="py-5">
                        <Section title="Temperature">
                            <Slider v-model="form.temperature" :min="0" :max="1" :step="0.01" />
                            <template #info>{{ form.temperature }}</template>
                            <template #description>
                                {{ description.temperature }}
                            </template>
                        </Section>
                    </div>
                    <div class="py-5">
                        <Section title="Maximum Length">
                            <Slider v-model="form.tokens" :min="20" :max="2500" :step="20" />
                            <template #info>{{ form.tokens }}</template>
                            <template #description>
                                {{ description.tokens }}
                            </template>
                        </Section>
                    </div>
                </div>
            </div>
        </template>

        <template #menu-bar>
            <NewDialogButton @click.prevent="onNewChat" />
        </template>

        <div class="flex h-full text-white">
            <div class="w-full">
                <div class="flex h-full flex-col justify-between">
                    <div class="flex-1 overflow-hidden bg-white text-zinc-900">
                        <div class="max-h-full overflow-y-auto">
                            <dl>
                                <ChatMessages :messages="messages" />
                            </dl>
                        </div>
                    </div>
                    <div class="flex justify-center shrink-0 mx-auto w-full px-2 py-2 my-2">
                        <Prompt v-model="form.prompt" :key="refreshKey" />
                    </div>
                </div>
            </div>
        </div>
    </OpenAILayout>
</template>
